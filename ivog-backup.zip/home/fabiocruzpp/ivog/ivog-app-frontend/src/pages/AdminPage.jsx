import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';
import styles from './AdminPage.module.css';

const ADMIN_TELEGRAM_ID = '1318210843';
const BackArrowIcon = () => (<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>);

// Componente para um único filtro na lista
const FiltroItem = ({ filtro, onRemove }) => (
    <div className={styles.filtroItem}>
        <span><strong>{filtro.tipo}:</strong> {filtro.valor}</span>
        <button type="button" onClick={onRemove} className={styles.removeButton}>&times;</button>
    </div>
);

function AdminPage() {
  const [configs, setConfigs] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [telegramId, setTelegramId] = useState(null);
  const [message, setMessage] = useState('');
  const [numPerguntas, setNumPerguntas] = useState('');
  
  const [newChallenge, setNewChallenge] = useState({
      titulo: '',
      descricao: '',
      data_inicio: '',
      data_fim: '',
      publico_alvo: {},
      filtros: []
  });
  const [challengeOptions, setChallengeOptions] = useState({
      temas: [], subtemas: [], cargos: [], canal_principal: []
  });
  const [currentFiltro, setCurrentFiltro] = useState({ tipo: 'tema', valor: '' });
  
  // Estado para o desafio legado
  const [legacySelectedTipo, setLegacySelectedTipo] = useState('tema');
  const [legacySelectedValue, setLegacySelectedValue] = useState('');

  useEffect(() => {
    const user = window.Telegram.WebApp.initDataUnsafe?.user;
    if (user && user.id.toString() === ADMIN_TELEGRAM_ID) {
      setIsAuthorized(true);
      const id = user.id.toString();
      setTelegramId(id);
      fetchAllInitialData(id);
    } else {
      setError('Acesso negado.');
      setLoading(false);
    }
  }, []);

  const fetchAllInitialData = async (id) => {
    try {
      if (!loading) setLoading(true);
      const [configsRes, temasRes, subtemasRes, cargosRes, canaisRes] = await Promise.all([
        api.get('/admin/configs', { params: { telegram_id: id } }),
        api.get('/admin/challenge-options', { params: { type: 'tema', telegram_id: id } }),
        api.get('/admin/challenge-options', { params: { type: 'subtema', telegram_id: id } }),
        api.get('/admin/challenge-options', { params: { type: 'cargo', telegram_id: id } }),
        api.get('/admin/challenge-options', { params: { type: 'canal_principal', telegram_id: id } }),
      ]);
      setConfigs(configsRes.data);
      setNumPerguntas(configsRes.data.num_max_perguntas_simulado || '');
      const options = {
          temas: temasRes.data, subtemas: subtemasRes.data,
          cargos: cargosRes.data, canal_principal: canaisRes.data
      };
      setChallengeOptions(options);
      
      if (options.temas.length > 0) {
        setCurrentFiltro(prev => ({ ...prev, valor: options.temas[0] }));
        setLegacySelectedValue(options.temas[0]);
      }
    } catch (err) {
      setError('Falha ao carregar dados do admin.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleToggle = async (key) => {
    setMessage(`Alterando...`);
    try {
      await api.post(`/admin/toggle_config/${key}`, { telegram_id: telegramId });
      await fetchAllInitialData(telegramId);
      setMessage(`Configuração alterada com sucesso!`);
    } catch (err) { setMessage(`Erro ao alterar.`); }
    setTimeout(() => setMessage(''), 3000);
  };

  const handleSetNumPerguntas = async (e) => {
    e.preventDefault();
    setMessage('Salvando...');
    try {
      await api.post('/admin/set_config/num_max_perguntas_simulado', { telegram_id: telegramId, value: numPerguntas });
      await fetchAllInitialData(telegramId);
      setMessage('Salvo com sucesso!');
    } catch (err) { setMessage('Erro ao salvar.'); }
    setTimeout(() => setMessage(''), 3000);
  };

  const handleNewChallengeChange = (e) => {
    const { name, value } = e.target;
    setNewChallenge(prev => ({ ...prev, [name]: value }));
  };

  const handlePublicoAlvoChange = (e) => {
      const { name, options } = e.target;
      const values = Array.from(options).filter(opt => opt.selected).map(opt => opt.value);
      setNewChallenge(prev => ({ ...prev, publico_alvo: { ...prev.publico_alvo, [name]: values.length > 0 ? values : undefined }}));
  };
  
  const handleAddFiltro = () => {
      if (!currentFiltro.valor) return;
      if (newChallenge.filtros.some(f => f.tipo === currentFiltro.tipo && f.valor === currentFiltro.valor)) return;
      setNewChallenge(prev => ({ ...prev, filtros: [...prev.filtros, currentFiltro] }));
  };

  const handleRemoveFiltro = (indexToRemove) => {
      setNewChallenge(prev => ({ ...prev, filtros: prev.filtros.filter((_, index) => index !== indexToRemove) }));
  };

  const handleCreateChallenge = async (e) => {
      e.preventDefault();
      setMessage('Criando desafio...');
      try {
          await api.post('/admin/challenges', { telegram_id: telegramId, ...newChallenge });
          setMessage('Desafio criado com sucesso!');
          setNewChallenge({ titulo: '', descricao: '', data_inicio: '', data_fim: '', publico_alvo: {}, filtros: [] });
      } catch (err) { setMessage('Erro ao criar desafio.'); }
      setTimeout(() => setMessage(''), 3000);
  };

  const handleActivateLegacyChallenge = async (e) => {
    e.preventDefault();
    if (!legacySelectedValue) { setMessage('Selecione um valor.'); return; }
    setMessage(`Ativando...`);
    try {
      await api.post('/admin/challenge/activate', { telegram_id: telegramId, tipo: legacySelectedTipo, valor: legacySelectedValue });
      await fetchAllInitialData(telegramId);
      setMessage('Desafio legado ativado!');
    } catch (err) { setMessage('Erro ao ativar.'); }
    setTimeout(() => setMessage(''), 3000);
  };

  const handleDeactivateLegacyChallenge = async () => {
    setMessage('Desativando...');
    try {
      await api.post('/admin/challenge/deactivate', { telegram_id: telegramId });
      await fetchAllInitialData(telegramId);
      setMessage('Desafio legado desativado!');
    } catch (err) { setMessage('Erro ao desativar.'); }
    setTimeout(() => setMessage(''), 3000);
  };
  
  useEffect(() => {
    const options = legacySelectedTipo === 'tema' ? challengeOptions.temas : challengeOptions.subtemas;
    if (options.length > 0) {
      setLegacySelectedValue(options[0]);
    } else {
      setLegacySelectedValue('');
    }
  }, [legacySelectedTipo, challengeOptions.temas, challengeOptions.subtemas]);

  if (!isAuthorized) return ( <div style={{textAlign: 'center'}}><h1 style={{color: 'red'}}>Acesso Negado</h1><Link to="/">Voltar</Link></div> );
  if (loading) return <p style={{ textAlign: 'center' }}>Carregando...</p>;
  if (error) return <p style={{textAlign: 'center', color: 'red'}}>{error}</p>;
  
  const legacyChallengeOptionsList = legacySelectedTipo === 'tema' ? challengeOptions.temas : challengeOptions.subtemas;
  const newChallengeFiltroOptionsList = currentFiltro.tipo === 'tema' ? challengeOptions.temas : challengeOptions.subtemas;

  return (
    <div className={styles.container}>
      <div className={styles.headerBar}><Link to="/" className={styles.headerIconBtn}><BackArrowIcon /></Link><h1 className={styles.screenTitle}>Painel Admin</h1></div>
      <div className={styles.contentArea}>
        <p className={styles.message}>{message}</p>
        
        <section className={styles.adminSection}>
          <h3 className={styles.sectionTitle}>Criar Desafio Personalizado</h3>
          <form onSubmit={handleCreateChallenge} className={styles.challengeForm}>
            <input name="titulo" value={newChallenge.titulo} onChange={handleNewChallengeChange} placeholder="Título do Desafio" className={styles.formInput} required />
            <textarea name="descricao" value={newChallenge.descricao} onChange={handleNewChallengeChange} placeholder="Descrição..." className={styles.formTextarea} rows="3"></textarea>
            <div className={styles.dateGroup}>
              <input type="datetime-local" name="data_inicio" value={newChallenge.data_inicio} onChange={handleNewChallengeChange} required />
              <input type="datetime-local" name="data_fim" value={newChallenge.data_fim} onChange={handleNewChallengeChange} required />
            </div>
            <h4 className={styles.subTitle}>Público-Alvo (segure CTRL/CMD para selecionar vários)</h4>
            <div className={styles.multiSelectGroup}>
              <select name="cargo" multiple onChange={handlePublicoAlvoChange} size="4" className={styles.formSelect}>{challengeOptions.cargos.map(o => <option key={o} value={o}>{o}</option>)}</select>
              <select name="canal_principal" multiple onChange={handlePublicoAlvoChange} size="3" className={styles.formSelect}>{challengeOptions.canal_principal.map(o => <option key={o} value={o}>{o}</option>)}</select>
            </div>
            <h4 className={styles.subTitle}>Filtros de Conteúdo</h4>
            <div className={styles.filtroAddGroup}>
              <select value={currentFiltro.tipo} onChange={e => setCurrentFiltro({ ...currentFiltro, tipo: e.target.value })} className={styles.formSelect}><option value="tema">Tema</option><option value="subtema">Subtema</option></select>
              <select value={currentFiltro.valor} onChange={e => setCurrentFiltro({ ...currentFiltro, valor: e.target.value })} className={styles.formSelect}>{newChallengeFiltroOptionsList.map(o => <option key={o} value={o}>{o}</option>)}</select>
              <button type="button" onClick={handleAddFiltro} className={styles.actionButton}>Adicionar Filtro</button>
            </div>
            <div className={styles.filtroList}>{newChallenge.filtros.map((f, i) => <FiltroItem key={`${f.valor}-${i}`} filtro={f} onRemove={() => handleRemoveFiltro(i)} />)}</div>
            <button type="submit" className={styles.submitButton}>Criar Desafio</button>
          </form>
        </section>

        <section className={styles.adminSection}>
          <h3 className={styles.sectionTitle}>Gerenciar Desafio Global (Legado)</h3>
          <div className={styles.configItem}>
            <span>Desafio Global Ativo:</span><strong>{configs.desafio_ativo ? `🔥 Sim (${configs.desafio_tipo}: ${configs.desafio_valor})` : '🧘 Não'}</strong>
          </div>
          {configs.desafio_ativo ? (<button onClick={handleDeactivateLegacyChallenge} className={`${styles.actionButton} ${styles.fullWidthButton} ${styles.deactivateButton}`}>Desativar Desafio Global</button>) : (
            <form onSubmit={handleActivateLegacyChallenge}>
              <select value={legacySelectedTipo} onChange={e => setLegacySelectedTipo(e.target.value)} className={styles.formSelect}>{/*...*/}</select>
              <select value={legacySelectedValue} onChange={e => setLegacySelectedValue(e.target.value)} className={styles.formSelect} style={{marginTop: '10px'}}>{legacyChallengeOptionsList.map(o => <option key={o} value={o}>{o.replace(/_/g, ' ')}</option>)}</select>
              <button type="submit" className={`${styles.actionButton} ${styles.primaryButton} ${styles.fullWidthButton}`}>Ativar Desafio Global</button>
            </form>
          )}
        </section>

        <section className={styles.adminSection}>
          <h3 className={styles.sectionTitle}>Configurações Gerais</h3>
          <div className={styles.configItem}><label>Simulado Livre</label><button onClick={() => handleToggle('simulado_livre_ativado')} className={`${styles.actionButton} ${configs.simulado_livre_ativado ? styles.primaryButton : styles.secondaryButton}`}>{configs.simulado_livre_ativado ? 'ATIVADO' : 'DESATIVADO'}</button></div>
          <div className={styles.configItem}><label>Feedback Detalhado</label><button onClick={() => handleToggle('feedback_detalhado_ativo')} className={`${styles.actionButton} ${configs.feedback_detalhado_ativo ? styles.primaryButton : styles.secondaryButton}`}>{configs.feedback_detalhado_ativo ? 'ATIVADO' : 'DESATIVADO'}</button></div>
          <form onSubmit={handleSetNumPerguntas} className={styles.configItem}><label htmlFor="numPerguntas">Qtd. Perguntas</label><div style={{display: 'flex', gap: '5px'}}><input type="number" id="numPerguntas" value={numPerguntas} onChange={(e) => setNumPerguntas(e.target.value)} className={styles.formInput}/><button type="submit" className={`${styles.actionButton} ${styles.secondaryButton}`}>Definir</button></div></form>
        </section>
      </div>
    </div>
  );
}

export default AdminPage;