import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import './ChallengesPage.css';

// Componente para exibir um único card de desafio
function ChallengeCard({ challenge }) {
  return (
    // O link agora envia 'desafio_id' com o ID real do desafio
    <Link to={`/quiz?desafio_id=${challenge.id}`} className="challenge-card-link">
      <div className="challenge-card">
        <h3>{challenge.titulo}</h3>
        <p>{challenge.descricao}</p>
        <div className="challenge-details">
          <span>Prêmio: {challenge.premio}</span>
          <span>Pontos: {challenge.pontos}</span>
        </div>
      </div>
    </Link>
  );
}

// Componente principal da página de desafios
function ChallengesPage() {
  const [challenges, setChallenges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchChallenges = async () => {
      try {
        const telegramId = window.Telegram.WebApp.initDataUnsafe.user.id;
        if (!telegramId) {
          throw new Error("Não foi possível obter o ID do usuário do Telegram.");
        }

        const response = await api.get('/challenges/available', {
          params: { telegram_id: telegramId }
        });
        
        setChallenges(response.data);
      } catch (err) {
        setError(err.response?.data?.message || err.message || 'Não foi possível carregar os desafios.');
      } finally {
        setLoading(false);
      }
    };

    fetchChallenges();
  }, []);

  if (loading) return <div style={{ textAlign: 'center' }}>Carregando desafios...</div>;
  if (error) return <div style={{ textAlign: 'center' }}>Erro ao carregar desafios: {error}</div>;

  return (
    <div className="challenges-page">
      <Link to="/" className="back-button">{'< Voltar'}</Link>
      <h1>Desafios Disponíveis</h1>
      {challenges.length > 0 ? (
        <div className="challenges-list">
          {challenges.map(challenge => (
            // A key aqui é crucial para o React identificar cada elemento
            <ChallengeCard key={challenge.id} challenge={challenge} />
          ))}
        </div>
      ) : (
        <p style={{ textAlign: 'center' }}>Nenhum desafio disponível para você no momento. Volte mais tarde!</p>
      )}
    </div>
  );
}

export default ChallengesPage;