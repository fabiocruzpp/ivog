import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import styles from './QuestionTab.module.css';
import QuestionForm from './QuestionForm'; // 1. IMPORTAMOS O NOVO FORMULÁRIO

function QuestionTab() {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // 2. ESTADOS PARA CONTROLAR O MODAL E A PERGUNTA EM EDIÇÃO
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState(null);

  const fetchQuestions = async () => { /* ... (código existente sem alterações) ... */ };
  useEffect(() => { fetchQuestions(); }, []);
  const handleDelete = async (questionId) => { /* ... (código existente sem alterações) ... */ };

  // 3. FUNÇÕES PARA ABRIR O MODAL
  const handleCreate = () => {
    setEditingQuestion(null); // Garante que o formulário estará em branco
    setIsFormOpen(true);
  };
  const handleEdit = (question) => {
    setEditingQuestion(question); // Passa os dados da pergunta para o formulário
    setIsFormOpen(true);
  };

  // 4. FUNÇÃO PARA LIDAR COM O ENVIO DO FORMULÁRIO (SALVAR)
  const handleSubmit = async (formData) => {
    try {
      if (editingQuestion) {
        // Se estamos editando, usamos o método PUT
        await api.put(`/admin/questions/${editingQuestion.id}`, formData);
        alert('Pergunta atualizada com sucesso!');
      } else {
        // Se não, estamos criando, usamos o método POST
        await api.post('/admin/questions', formData);
        alert('Pergunta criada com sucesso!');
      }
      setIsFormOpen(false); // Fecha o modal
      fetchQuestions();   // Atualiza a lista de perguntas
    } catch (err) {
      alert('Erro ao salvar a pergunta.');
      console.error('Erro ao salvar:', err);
    }
  };
  
  const renderContent = () => {
    if (loading) return <p className={styles.message}>Carregando perguntas...</p>;
    if (error) return <p className={`${styles.message} ${styles.error}`}>{error}</p>;
    if (questions.length === 0) return <p className={styles.message}>Nenhuma pergunta encontrada. Clique em "Criar Nova" para começar.</p>;
    
    return (
        <div className={styles.questionList}>
            {questions.map(q => (
            <div key={q.id} className={styles.questionCard}>
                <div className={styles.questionMain}>
                    <span className={styles.questionId}>#{q.id}</span>
                    <p className={styles.questionText}>{q.texto_pergunta}</p>
                </div>
                <div className={styles.questionDetails}>
                    <span><strong>Tema:</strong> {q.tema}</span>
                    <span><strong>Pontos:</strong> {q.pontos}</span>
                </div>
                <ul className={styles.alternativesList}>
                    {q.alternativas.map(alt => (
                        <li key={alt.id} className={alt.is_correta ? styles.correctAlternative : ''}>
                           {alt.texto_alternativa} {alt.is_correta ? '✔' : ''}
                        </li>
                    ))}
                </ul>
                <div className={styles.questionActions}>
                    <button className={styles.editButton}>Editar</button>
                    <button onClick={() => handleDelete(q.id)} className={styles.deleteButton}>Excluir</button>
                </div>
            </div>
            ))}
      </div>
    );
  };

 return (
    <div className={styles.questionTabContainer}>
      <div className={styles.toolbar}>
        <h2>Gerenciador de Perguntas ({questions.length})</h2>
        {/* O botão agora chama a função para abrir o formulário */}
        <button onClick={handleCreate} className={styles.createButton}>+ Criar Nova Pergunta</button>
      </div>

      {/* Renderiza a lista de perguntas */}
      {renderContent()}

      {/* 5. RENDERIZAÇÃO CONDICIONAL DO MODAL/FORMULÁRIO */}
      {isFormOpen && (
        <QuestionForm 
          initialData={editingQuestion}
          onSubmit={handleSubmit}
          onCancel={() => setIsFormOpen(false)}
        />
      )}
    </div>
  );
}

export default QuestionTab;