import React, { useState, useEffect } from 'react';
import styles from './QuestionForm.module.css'; // Criaremos este CSS a seguir

function QuestionForm({ initialData, onSubmit, onCancel }) {
  // O estado 'formData' guarda todos os dados da pergunta que está sendo criada/editada
  const [formData, setFormData] = useState({
    texto_pergunta: '',
    tema: '',
    subtema: '',
    pontos: 10,
    feedback: '',
    fonte: '',
    // ... outros campos do seu CSV
    alternativas: [
      { texto_alternativa: '', is_correta: true },
      { texto_alternativa: '', is_correta: false }
    ]
  });

  // useEffect para popular o formulário quando estivermos editando uma pergunta existente
  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);

  // Função para lidar com mudanças nos inputs normais (texto, tema, etc.)
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Função para lidar com mudanças nas alternativas
  const handleAlternativeChange = (index, text) => {
    const novasAlternativas = [...formData.alternativas];
    novasAlternativas[index].texto_alternativa = text;
    setFormData(prev => ({ ...prev, alternativas: novasAlternativas }));
  };
  
  // Função para definir qual alternativa é a correta
  const handleCorrectChange = (index) => {
    const novasAlternativas = formData.alternativas.map((alt, i) => ({
      ...alt,
      is_correta: i === index
    }));
    setFormData(prev => ({ ...prev, alternativas: novasAlternativas }));
  };

  // Função para adicionar uma nova alternativa em branco
  const addAlternative = () => {
    setFormData(prev => ({
      ...prev,
      alternativas: [...prev.alternativas, { texto_alternativa: '', is_correta: false }]
    }));
  };

  // Função para remover uma alternativa
  const removeAlternative = (index) => {
    if (formData.alternativas.length <= 2) {
        alert('Uma pergunta deve ter no mínimo 2 alternativas.');
        return;
    }
    const novasAlternativas = formData.alternativas.filter((_, i) => i !== index);
    // Se a alternativa removida era a correta, marca a primeira como correta
    if (!novasAlternativas.some(a => a.is_correta)) {
        novasAlternativas[0].is_correta = true;
    }
    setFormData(prev => ({ ...prev, alternativas: novasAlternativas }));
  };

  // Função chamada quando o formulário é enviado
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData); // Envia os dados para a função passada por prop
  };

  return (
    <div className={styles.modalBackdrop}>
      <div className={styles.modalContent}>
        <form onSubmit={handleSubmit}>
          <h2>{initialData ? 'Editar Pergunta' : 'Criar Nova Pergunta'}</h2>
          
          <label>Texto da Pergunta:</label>
          <textarea name="texto_pergunta" value={formData.texto_pergunta} onChange={handleChange} required />
          
          <div className={styles.grid2cols}>
              <label>Tema: <input type="text" name="tema" value={formData.tema} onChange={handleChange} required /></label>
              <label>Subtema: <input type="text" name="subtema" value={formData.subtema} onChange={handleChange} /></label>
          </div>
          <div className={styles.grid2cols}>
             <label>Pontos: <input type="number" name="pontos" value={formData.pontos} onChange={handleChange} /></label>
             <label>Fonte: <input type="text" name="fonte" value={formData.fonte} onChange={handleChange} /></label>
          </div>
          
          <label>Alternativas:</label>
          {formData.alternativas.map((alt, index) => (
            <div key={index} className={styles.alternativeRow}>
              <input type="radio" name="correta" checked={alt.is_correta} onChange={() => handleCorrectChange(index)} />
              <input type="text" className={styles.alternativeInput} value={alt.texto_alternativa} onChange={(e) => handleAlternativeChange(index, e.target.value)} required />
              <button type="button" onClick={() => removeAlternative(index)} className={styles.removeButton}>&times;</button>
            </div>
          ))}
          <button type="button" onClick={addAlternative} className={styles.addButton}>+ Adicionar Alternativa</button>
          
          <div className={styles.formActions}>
            <button type="button" onClick={onCancel} className={styles.cancelButton}>Cancelar</button>
            <button type="submit" className={styles.saveButton}>Salvar</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default QuestionForm;