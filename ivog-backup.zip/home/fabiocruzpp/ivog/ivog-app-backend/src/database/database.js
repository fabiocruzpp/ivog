import sqlite3 from 'sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuração para encontrar o caminho do banco de dados
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(__dirname, '..', '..', 'dados.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados SQLite:', err.message);
  } else {
    console.log('Conexão com o banco de dados SQLite estabelecida com sucesso.');
    initializeDb(); // Função que fará toda a configuração inicial
  }
});

// Função principal que inicializa a estrutura completa do banco de dados
const initializeDb = () => {
  // Bloco 'serialize' garante que os comandos rodem em ordem
  db.serialize(() => {
    // Ativa o suporte a chaves estrangeiras para garantir a integridade dos dados
    db.run('PRAGMA foreign_keys = ON');

    // Tabela de Usuários
    db.run(`
      CREATE TABLE IF NOT EXISTS usuarios (
        telegram_id INTEGER PRIMARY KEY,
        first_name TEXT,
        photo_url TEXT,
        cargo TEXT,
        canal_principal TEXT,
        ddd TEXT,
        rede_parceiro TEXT,
        loja_revenda TEXT,
        data_cadastro TEXT
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'usuarios':", err.message);
      else console.log("Tabela 'usuarios' verificada/criada.");
    });
    
    // Tabela de Perguntas (baseada na estrutura do CSV)
    db.run(`
      CREATE TABLE IF NOT EXISTS perguntas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        texto_pergunta TEXT NOT NULL,
        tema TEXT NOT NULL,
        subtema TEXT,
        feedback TEXT,
        publico_alvo_json TEXT DEFAULT '[]',
        canal_json TEXT DEFAULT '[]',
        fonte TEXT,
        tipo_pergunta TEXT,
        nome_imagem TEXT,
        pontos INTEGER DEFAULT 10
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'perguntas':", err.message);
      else console.log("Tabela 'perguntas' verificada/criada.");
    });

    // Tabela para armazenar as alternativas de cada pergunta
    db.run(`
      CREATE TABLE IF NOT EXISTS alternativas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pergunta_id INTEGER NOT NULL,
        texto_alternativa TEXT NOT NULL,
        is_correta INTEGER NOT NULL DEFAULT 0, -- 0 para falso, 1 para verdadeiro
        FOREIGN KEY (pergunta_id) REFERENCES perguntas (id) ON DELETE CASCADE
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'alternativas':", err.message);
      else console.log("Tabela 'alternativas' verificada/criada.");
    });

    // Tabela de Desafios
    db.run(`
      CREATE TABLE IF NOT EXISTS desafios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT NOT NULL,
        descricao TEXT,
        data_inicio TEXT NOT NULL,
        data_fim TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'inativo',
        premio TEXT,
        pontos INTEGER DEFAULT 0,
        publico_alvo_json TEXT
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'desafios':", err.message);
      else console.log("Tabela 'desafios' verificada/criada.");
    });

    // Tabela de Filtros para os Desafios
    db.run(`
      CREATE TABLE IF NOT EXISTS desafio_filtros (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        desafio_id INTEGER NOT NULL,
        tipo_filtro TEXT NOT NULL,
        valor_filtro TEXT NOT NULL,
        FOREIGN KEY (desafio_id) REFERENCES desafios (id) ON DELETE CASCADE
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'desafio_filtros':", err.message);
      else console.log("Tabela 'desafio_filtros' verificada/criada.");
    });

    // Tabela de Simulados (Quiz)
    db.run(`
      CREATE TABLE IF NOT EXISTS simulados (
        id_simulado INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER NOT NULL,
        data_inicio TEXT NOT NULL,
        data_fim TEXT,
        status TEXT,
        contexto_desafio TEXT,
        FOREIGN KEY (telegram_id) REFERENCES usuarios (telegram_id)
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'simulados':", err.message);
      else console.log("Tabela 'simulados' verificada/criada.");
    });

    // Tabela para guardar cada resposta de cada simulado
    db.run(`
      CREATE TABLE IF NOT EXISTS respostas_simulado (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_simulado INTEGER NOT NULL,
        telegram_id INTEGER NOT NULL,
        pergunta TEXT NOT NULL,
        resposta_usuario TEXT,
        resposta_correta TEXT,
        acertou INTEGER,
        tema TEXT,
        subtema TEXT,
        FOREIGN KEY (id_simulado) REFERENCES simulados (id_simulado) ON DELETE CASCADE,
        FOREIGN KEY (telegram_id) REFERENCES usuarios (telegram_id)
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'respostas_simulado':", err.message);
      else console.log("Tabela 'respostas_simulado' verificada/criada.");
    });

    // Tabela com os resultados finais de cada simulado
    db.run(`
      CREATE TABLE IF NOT EXISTS resultados (
        id_resultado INTEGER PRIMARY KEY AUTOINCREMENT,
        id_simulado INTEGER NOT NULL,
        telegram_id INTEGER NOT NULL,
        num_acertos INTEGER,
        total_perguntas INTEGER,
        pontos INTEGER,
        data TEXT NOT NULL,
        FOREIGN KEY (id_simulado) REFERENCES simulados (id_simulado) ON DELETE CASCADE,
        FOREIGN KEY (telegram_id) REFERENCES usuarios (telegram_id)
      )
    `, (err) => {
      if (err) console.error("Erro ao criar tabela 'resultados':", err.message);
      else console.log("Tabela 'resultados' verificada/criada.");
    });

    // Tabela de Configurações do Painel Admin
    db.run(`
        CREATE TABLE IF NOT EXISTS configuracoes (
            chave TEXT PRIMARY KEY,
            valor TEXT
        )
    `, (err) => {
        if (err) console.error("Erro ao criar tabela 'configuracoes':", err.message);
        else {
            console.log("Tabela 'configuracoes' verificada/criada.");
            seedInitialConfigs();
        }
    });
  });
};

const seedInitialConfigs = () => {
  const defaultConfigs = [
    { chave: 'simulado_livre_ativado', valor: 'true' },
    { chave: 'feedback_detalhado_ativo', valor: 'false' },
    { chave: 'num_max_perguntas_simulado', valor: '10' },
    { chave: 'desafio_ativo', valor: 'false' },
    { chave: 'desafio_tipo', valor: '' },
    { chave: 'desafio_valor', valor: '' }
  ];
  const sql = `INSERT OR IGNORE INTO configuracoes (chave, valor) VALUES (?, ?)`;
  defaultConfigs.forEach(config => {
    db.run(sql, [config.chave, config.valor]);
  });
  console.log('Configurações iniciais verificadas/inseridas.');
};

export default db;