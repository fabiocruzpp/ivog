import express from 'express';
import {
  // Funções de configuração existentes
  getAdminConfigsController,
  toggleAdminConfigController,
  setAdminConfigController,

  // Funções de desafios existentes
  getChallengeOptionsController,
  createChallengeController,
  activateChallengeController,
  deactivateChallengeController,
  getAllDistinctChallengesController,
  getChallengeStatsController,

  // NOVAS FUNÇÕES de gerenciamento de perguntas
  getAllQuestionsController,
  createQuestionController,
  updateQuestionController,
  deleteQuestionController

} from '../controllers/adminController.js';

const router = express.Router();

// Rotas de Configuração Geral
router.get('/configs', getAdminConfigsController);
router.post('/configs/toggle/:key', toggleAdminConfigController);
router.post('/configs/set/:key', setAdminConfigController);

// Rotas de Desafios
router.post('/challenges', createChallengeController);
router.get('/challenge-options', getChallengeOptionsController);
router.post('/challenges/activate', activateChallengeController);
router.post('/challenges/deactivate', deactivateChallengeController);
router.get('/challenges/distinct', getAllDistinctChallengesController);
router.get('/challenge-stats', getChallengeStatsController);

// Rotas de Gerenciamento de Perguntas (CRUD)
router.get('/questions', getAllQuestionsController);
router.post('/questions', createQuestionController);
router.put('/questions/:id', updateQuestionController);
router.delete('/questions/:id', deleteQuestionController);

export default router;