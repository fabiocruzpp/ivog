import db from '../database/database.js';
import { promisify } from 'util';

// Promisificando os métodos do DB que retornam múltiplos valores ou um valor
const dbGet = promisify(db.get.bind(db));
const dbAll = promisify(db.all.bind(db));

// Função wrapper customizada para db.run que retorna o 'this' da callback
const dbRunAsync = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) {
        reject(err);
      } else {
        // 'this' aqui contém as propriedades lastID e changes
        resolve(this);
      }
    });
  });
};

// Função para embaralhar um array
const shuffleArray = (array) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};


// --- CONTROLLER PARA INICIAR UM QUIZ (VERSÃO FINAL COM BANCO DE DADOS) ---
export const startQuizController = async (req, res) => {
  try {
    const { telegram_id, cargo, canal_principal, desafio_id } = req.query;
    const NUMERO_DE_PERGUNTAS = 10;

    if (!telegram_id || !cargo || !canal_principal) {
      return res.status(400).json({ message: "Parâmetros insuficientes para iniciar o quiz." });
    }

    let baseQuery = `
        SELECT p.id as pergunta_id, p.texto_pergunta, p.tema, p.subtema, p.feedback, p.pontos,
               a.id as alternativa_id, a.texto_alternativa, a.is_correta
        FROM perguntas p
        JOIN alternativas a ON p.id = a.pergunta_id
    `;
    const params = [];
    let whereClauses = [];

    if (desafio_id) {
      // Lógica para quiz de desafio
      const filtros = await dbAll(`SELECT tipo_filtro, valor_filtro FROM desafio_filtros WHERE desafio_id = ?`, [desafio_id]);
      if (filtros.length === 0) {
        return res.status(404).json({ message: "Este desafio não possui critérios de perguntas definidos." });
      }
      filtros.forEach(filtro => {
        whereClauses.push(`p.${filtro.tipo_filtro} = ?`);
        params.push(filtro.valor_filtro);
      });
    } else {
      // Lógica para quiz normal (baseado no perfil do usuário)
      whereClauses.push(`(json_valid(p.publico_alvo_json) AND (json_array_length(p.publico_alvo_json) = 0 OR EXISTS (SELECT 1 FROM json_each(p.publico_alvo_json) WHERE value = ?)))`);
      params.push(cargo);
      whereClauses.push(`(json_valid(p.canal_json) AND (json_array_length(p.canal_json) = 0 OR EXISTS (SELECT 1 FROM json_each(p.canal_json) WHERE value = ?)))`);
      params.push(canal_principal);
    }
    
    // Constrói a sub-query para selecionar os IDs das perguntas que correspondem aos filtros
    if (whereClauses.length > 0) {
        baseQuery += ` WHERE p.id IN (SELECT DISTINCT id FROM perguntas p WHERE ${whereClauses.join(' AND ')})`;
    }

    const flatResults = await dbAll(baseQuery, params);

    if (flatResults.length === 0) {
      return res.status(404).json({ message: "Nenhuma pergunta encontrada para os critérios fornecidos." });
    }

    const questionsMap = new Map();
    flatResults.forEach(row => {
        if (!questionsMap.has(row.pergunta_id)) {
            questionsMap.set(row.pergunta_id, {
                id: row.pergunta_id,
                pergunta_formatada_display: row.texto_pergunta,
                tema: row.tema, subtema: row.subtema, feedback: row.feedback, pontos: row.pontos,
                alternativas: []
            });
        }
        questionsMap.get(row.pergunta_id).alternativas.push({
            id: row.alternativa_id,
            texto_alternativa: row.texto_alternativa,
            is_correta: row.is_correta === 1
        });
    });

    const eligibleQuestions = Array.from(questionsMap.values()).map(q => {
        const correta = q.alternativas.find(a => a.is_correta)?.texto_alternativa || '';
        const alternativasText = shuffleArray(q.alternativas.map(a => a.texto_alternativa));
        return { ...q, correta: correta, alternativas: alternativasText };
    });

    const shuffledQuestions = shuffleArray(eligibleQuestions);
    const selectedQuestions = shuffledQuestions.slice(0, Math.min(eligibleQuestions.length, NUMERO_DE_PERGUNTAS));
    
    const contextoParaSalvar = desafio_id ? `desafio_id:${desafio_id}` : null;

    const simuladoInsertResult = await dbRunAsync(
      `INSERT INTO simulados (telegram_id, data_inicio, status, contexto_desafio) VALUES (?, ?, ?, ?)`,
      [telegram_id, new Date().toISOString(), 'iniciado', contextoParaSalvar]
    );
    const simulado_id = simuladoInsertResult.lastID;

    res.status(200).json({
      simulado_id,
      questions: selectedQuestions,
      total_perguntas_no_simulado: selectedQuestions.length,
    });

  } catch (error) {
    console.error("Erro ao iniciar o quiz:", error);
    res.status(500).json({ message: "Erro interno do servidor ao iniciar quiz." });
  }
};


// --- CONTROLLER PARA SALVAR UMA RESPOSTA ---
export const saveAnswerController = async (req, res) => {
  try {
    const {
      simulado_id, telegram_id, pergunta, resposta_usuario,
      resposta_correta, acertou, tema, subtema
    } = req.body;

    await dbRunAsync(
      `INSERT INTO respostas_simulado (id_simulado, telegram_id, pergunta, resposta_usuario, resposta_correta, acertou, tema, subtema)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [simulado_id, telegram_id, pergunta, resposta_usuario, resposta_correta, acertou ? 1 : 0, tema, subtema]
    );

    res.status(200).send({ message: "Resposta salva com sucesso." });

  } catch (error) {
    console.error("Erro ao salvar resposta:", error);
    res.status(500).json({ message: "Erro interno do servidor ao salvar resposta." });
  }
};


// --- CONTROLLER PARA FINALIZAR UM QUIZ ---
export const finishQuizController = async (req, res) => {
  try {
    const { telegram_id, simulado_id, num_acertos, total_perguntas } = req.body;
    const pontos = num_acertos * 10;

    await dbRunAsync(
      `INSERT INTO resultados (id_simulado, telegram_id, pontos, num_acertos, total_perguntas, data)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [simulado_id, telegram_id, pontos, num_acertos, total_perguntas, new Date().toISOString()]
    );

    await dbRunAsync(
      `UPDATE simulados SET status = ?, data_fim = ? WHERE id_simulado = ?`,
      ['finalizado', new Date().toISOString(), simulado_id]
    );

    res.status(200).json({
      message: "Quiz finalizado com sucesso!",
      pontos,
      num_acertos,
      total_perguntas
    });

  } catch (error) {
    console.error("Erro ao finalizar o quiz:", error);
    res.status(500).json({ message: "Erro interno do servidor ao finalizar quiz." });
  }
};